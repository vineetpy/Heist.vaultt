let vault = [];
let multiplier = 1;
let gameOver = false;
let tilesRevealed = 0;
const multipliers = [1.2, 1.5, 2, 3, 5, 10, 25, 50, 100];
const maxMultiplier = 100;

function playSound(id) {
  const sound = document.getElementById(id);
  if (sound) sound.play();
}

function generateVault() {
  const contents = [];
  for (let i = 0; i < 16; i++) {
    const rand = Math.random();
    if (rand < 0.1) contents.push('ALARM');
    else if (rand < 0.2) contents.push('EMPTY');
    else contents.push(multipliers[Math.floor(Math.random() * multipliers.length)]);
  }
  return contents.sort(() => 0.5 - Math.random());
}

function createGrid() {
  const grid = document.getElementById('vault-grid');
  grid.innerHTML = '';
  for (let i = 0; i < 16; i++) {
    const tile = document.createElement('div');
    tile.className = 'tile';
    tile.dataset.index = i;
    tile.onclick = () => revealTile(i);
    grid.appendChild(tile);
  }
}

function revealTile(index) {
  if (gameOver) return;

  const tileEl = document.querySelectorAll('.tile')[index];
  if (tileEl.classList.contains('revealed')) return;

  tileEl.classList.add('revealed');
  tilesRevealed++;

  const content = vault[index];
  if (content === 'ALARM') {
    tileEl.textContent = '🚨';
    tileEl.classList.add('alarm');
    document.getElementById('status').textContent = 'ALERT! You got caught!';
    playSound('alarm-sound');
    gameOver = true;
  } else if (content === 'EMPTY') {
    tileEl.textContent = '🕳️';
  } else {
    multiplier *= content;
    tileEl.textContent = `${content}x`;
    tileEl.classList.add('loot');
    playSound('loot-sound');
    document.getElementById('multiplier').textContent = multiplier.toFixed(2) + 'x';
    if (content == maxMultiplier) {
      document.getElementById('status').textContent = '🔥 JACKPOT! You hit 100x!';
      playSound('win-sound');
    }
  }

  if (tilesRevealed === 16 && !gameOver) {
    document.getElementById('status').textContent = 'Full vault cleared! Bonus x1.25 applied!';
    multiplier *= 1.25;
    document.getElementById('multiplier').textContent = multiplier.toFixed(2) + 'x';
    playSound('win-sound');
    gameOver = true;
  }
}

function cashOut() {
  if (gameOver || multiplier === 1) return;
  document.getElementById('status').textContent = `You escaped with ${multiplier.toFixed(2)}x! 💰`;
  playSound('win-sound');
  gameOver = true;
}

function startGame() {
  vault = generateVault();
  multiplier = 1;
  tilesRevealed = 0;
  gameOver = false;
  document.getElementById('multiplier').textContent = '1x';
  document.getElementById('status').textContent = 'Stealing in progress...';
  createGrid();
}

startGame();